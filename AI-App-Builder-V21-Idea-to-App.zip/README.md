# AI App Builder V21

Core experience:
App Idea Finder → AI Build → Preview/Test → Web/PWA → AI Modify → Growth.

Customer-facing UI intentionally hides technical details and download/revenue analytics.
Admin layer is reserved for platform management.

The current package is a frontend product prototype. Real AI/Vercel/App Store/Google Play publishing requires server-side credentials and API integrations.
